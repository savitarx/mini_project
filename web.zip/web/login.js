function fun(){
  document.getElementsByClassName("box").submit();
  location.replace("index.html");
}